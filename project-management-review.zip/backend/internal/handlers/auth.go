package handlers

import (
	"database/sql"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"

	"golang.org/x/crypto/bcrypt"

	"office-task-manager/backend/internal/auth"
)

type AuthHandler struct {
	DB *sql.DB
}

type loginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type loginResponse struct {
	Token     string    `json:"token"`
	TokenType string    `json:"token_type"`
	ExpiresIn int       `json:"expires_in"`
	User      loginUser `json:"user"`
}

type loginUser struct {
	ID             string `json:"id"`
	FullName       string `json:"full_name"`
	Email          string `json:"email"`
	Role           string `json:"role"`
	CanAssignTasks bool   `json:"can_assign_tasks"`
}

func (h AuthHandler) Login(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.Header().Set("Allow", http.MethodPost)
		writeAuthJSON(w, http.StatusMethodNotAllowed, map[string]string{
			"error": "method not allowed",
		})
		return
	}

	if h.DB == nil {
		writeAuthJSON(w, http.StatusInternalServerError, map[string]string{
			"error": "database unavailable",
		})
		return
	}

	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	defer r.Body.Close()

	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()

	var req loginRequest
	if err := decoder.Decode(&req); err != nil {
		writeAuthJSON(w, http.StatusBadRequest, map[string]string{
			"error": "invalid request body",
		})
		return
	}

	// Reject additional JSON values after the first object.
	var extra any
	if err := decoder.Decode(&extra); !errors.Is(err, io.EOF) {
		writeAuthJSON(w, http.StatusBadRequest, map[string]string{
			"error": "request must contain one JSON object",
		})
		return
	}

	req.Email = strings.ToLower(strings.TrimSpace(req.Email))
	if req.Email == "" || req.Password == "" {
		writeAuthJSON(w, http.StatusBadRequest, map[string]string{
			"error": "email and password are required",
		})
		return
	}

	var user loginUser
	var passwordHash string
	var isActive bool

	err := h.DB.QueryRowContext(
		r.Context(),
		`SELECT id::text, full_name, email, role::text,
		        can_assign_tasks, password_hash, is_active
		 FROM users
		 WHERE lower(email) = $1`,
		req.Email,
	).Scan(
		&user.ID,
		&user.FullName,
		&user.Email,
		&user.Role,
		&user.CanAssignTasks,
		&passwordHash,
		&isActive,
	)

	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			writeAuthJSON(w, http.StatusUnauthorized, map[string]string{
				"error": "invalid email or password",
			})
			return
		}

		writeAuthJSON(w, http.StatusInternalServerError, map[string]string{
			"error": "unable to process login",
		})
		return
	}

	if !isActive || bcrypt.CompareHashAndPassword(
		[]byte(passwordHash),
		[]byte(req.Password),
	) != nil {
		writeAuthJSON(w, http.StatusUnauthorized, map[string]string{
			"error": "invalid email or password",
		})
		return
	}

	token, err := auth.SignToken(
		user.ID,
		user.Email,
		user.Role,
		user.CanAssignTasks,
	)
	if err != nil {
		writeAuthJSON(w, http.StatusInternalServerError, map[string]string{
			"error": "unable to create authentication token",
		})
		return
	}

	writeAuthJSON(w, http.StatusOK, loginResponse{
		Token:     token,
		TokenType: "Bearer",
		ExpiresIn: 28800,
		User:      user,
	})
}

func writeAuthJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.WriteHeader(status)

	_ = json.NewEncoder(w).Encode(value)
}
