package handlers

import (
	"encoding/json"
	"net/http"

	"office-task-manager/backend/internal/auth"
)

func (h AuthHandler) Me(w http.ResponseWriter, r *http.Request) {
	claims, ok := auth.ClaimsFromContext(r.Context())
	if !ok {
		http.Error(w, `{"error":"authentication required"}`, http.StatusUnauthorized)
		return
	}

	var user loginUser
	var isActive bool

	err := h.DB.QueryRowContext(
		r.Context(),
		`SELECT id::text, full_name, email, role::text,
		        can_assign_tasks, is_active
		 FROM users
		 WHERE id = $1`,
		claims.UserID,
	).Scan(
		&user.ID,
		&user.FullName,
		&user.Email,
		&user.Role,
		&user.CanAssignTasks,
		&isActive,
	)

	if err != nil || !isActive {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		_ = json.NewEncoder(w).Encode(map[string]string{
			"error": "user not found or inactive",
		})
		return
	}

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"user": user,
	})
}
