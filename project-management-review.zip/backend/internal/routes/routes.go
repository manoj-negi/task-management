package routes

import (
	"database/sql"

	"net/http"

	"office-task-manager/backend/internal/auth"
	"office-task-manager/backend/internal/handlers"
)

func New(db *sql.DB) http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("/api/health", handlers.Health(db))

	authHandler := handlers.AuthHandler{DB: db}
	mux.HandleFunc("/api/auth/login", authHandler.Login)

	mux.Handle(
		"/api/auth/me",
		protected(db, http.HandlerFunc(authHandler.Me)),
	)
	mux.Handle(
		"/api/dashboard",
		protected(db, http.HandlerFunc(handlers.Dashboard(db))),
	)
	mux.Handle("/api/tasks", protected(db, http.HandlerFunc(handlers.CreateTask(db))))
	mux.Handle("/api/assignable-users", protected(db, http.HandlerFunc(handlers.AssignableUsers(db))))

	mux.Handle("/api/tasks/", protected(db, http.HandlerFunc(handlers.TaskAction(db))))

	mux.Handle("/api/admin/employees", protected(db, handlers.Employees(db)))
	mux.Handle("/api/admin/employees/", protected(db, handlers.Employees(db)))
	mux.Handle("/api/admin/reviews", protected(db, http.HandlerFunc(handlers.AdminReviews(db))))
	mux.Handle("/api/admin/tasks/", protected(db, http.HandlerFunc(handlers.ReviewTask(db))))

	return corsMiddleware(mux)
}

func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PATCH, PUT, DELETE, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
		w.Header().Set("Access-Control-Max-Age", "0")

		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}

		next.ServeHTTP(w, r)
	})
}

// protected validates the signed token and then refreshes role/permissions from
// PostgreSQL before a handler makes authorization decisions.
func protected(db *sql.DB, handler http.Handler) http.Handler {
	return auth.RequireAuth(auth.RequireCurrentUser(db, handler))
}
