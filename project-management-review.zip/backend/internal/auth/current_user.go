package auth

import (
	"context"
	"database/sql"
	"encoding/json"
	"net/http"
)

// RequireCurrentUser refreshes authorization-relevant claims from PostgreSQL on
// every protected request. JWTs identify the user; the database remains the
// source of truth for role, active status, and task-assignment permission.
func RequireCurrentUser(db *sql.DB, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		claims, ok := ClaimsFromContext(r.Context())
		if !ok {
			writeCurrentUserError(w, http.StatusUnauthorized, "authentication required")
			return
		}

		var role, email string
		var canAssign, active bool
		err := db.QueryRowContext(r.Context(),
			`SELECT email, role::text, can_assign_tasks, is_active FROM users WHERE id = $1::uuid`,
			claims.UserID,
		).Scan(&email, &role, &canAssign, &active)
		if err != nil || !active {
			writeCurrentUserError(w, http.StatusUnauthorized, "user not found or inactive")
			return
		}

		// Claims are request-local; updating them cannot modify the signed token.
		refreshed := *claims
		refreshed.Email = email
		refreshed.Role = role
		refreshed.CanAssignTasks = canAssign
		ctx := context.WithValue(r.Context(), claimsContextKey, &refreshed)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func writeCurrentUserError(w http.ResponseWriter, status int, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(map[string]string{"error": message})
}
