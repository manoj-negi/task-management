import { ApiRequestError } from "./auth"

const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL || "http://localhost:8080"
).replace(/\/$/, "")

export async function performTaskAction(
  token: string,
  taskId: string,
  action: "start" | "submit",
): Promise<{ message: string }> {
  let response: Response
  try {
    response = await fetch(
      `${API_BASE_URL}/api/tasks/${encodeURIComponent(taskId)}/${action}`,
      {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      },
    )
  } catch {
    throw new Error("Cannot connect to the server. Make sure the backend is running.")
  }

  const data = await response.json().catch(() => ({})) as { message?: string; error?: string }
  if (!response.ok) {
    throw new ApiRequestError(data.error || "Could not update task.", response.status)
  }
  return { message: data.message || "Task updated." }
}
